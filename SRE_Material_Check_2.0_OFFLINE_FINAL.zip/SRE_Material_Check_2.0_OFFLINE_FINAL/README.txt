SRE Material Check 2.0 – GG + verbesserter QR-Scanner

QR-Scanner: Rückkamera, mehrere Kameras auswählbar, native BarcodeDetector-Erkennung, jsQR-Fallback, bessere Berechtigungsfehler und manuelle Eingabe.

Kamera benötigt HTTPS oder localhost.
