const CACHE="sre-material-check-v22";
const ASSETS=["./","./index.html","./manifest.webmanifest","./jsQR.js"];
const QR_CDN="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js";

self.addEventListener("install",e=>e.waitUntil((async()=>{
  const c=await caches.open(CACHE);
  await c.addAll(["./","./index.html","./manifest.webmanifest"]);
  try{
    const r=await fetch(QR_CDN,{mode:"cors",cache:"no-store"});
    if(r.ok) await c.put("./jsQR.js",r.clone());
  }catch(err){}
  await self.skipWaiting();
})()));

self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(a=>Promise.all(a.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));

self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET") return;
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(resp=>{
    if(new URL(e.request.url).origin===location.origin){
      const copy=resp.clone(); caches.open(CACHE).then(c=>c.put(e.request,copy)).catch(()=>{});
    }
    return resp;
  }).catch(()=>caches.match("./index.html"))));
});
